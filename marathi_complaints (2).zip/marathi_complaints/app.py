import os
import sqlite3
import datetime
from flask import Flask, render_template, request, jsonify, send_file
from nlp.preprocessing import preprocess_text
from nlp.classifier import classify_complaint, train_model
from nlp.extractor import extract_information
from nlp.formalizer import formalize_complaint
from generator.formats import generate_document
from generator.export import create_pdf, create_docx
from nlp.translator import translate_text

app = Flask(__name__)
app.config['SECRET_KEY'] = 'marathi-nlp-secret'
app.config['GENERATED_FOLDER'] = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'generated')

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'complaints.db')

def init_db():
    """Initializes the SQLite database for history tracking."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            reference_number TEXT,
            raw_text TEXT,
            category TEXT,
            confidence REAL,
            format TEXT,
            generated_text TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    conn.close()

# Ensure directories and models are ready
os.makedirs(app.config['GENERATED_FOLDER'], exist_ok=True)
init_db()

try:
    train_model()
except Exception as e:
    print(f"Warning: Model could not be trained. {e}")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/analyze', methods=['POST'])
def analyze():
    data = request.json
    raw_text = data.get('text', '')
    
    if not raw_text.strip():
        return jsonify({'error': 'कृपया तुमची तक्रार लिहा.'}), 400
        
    cleaned_text = preprocess_text(raw_text)
    classification = classify_complaint(cleaned_text)
    fields = extract_information(cleaned_text, classification['category'])
    
    return jsonify({
        'category': classification['category'],
        'confidence': classification['confidence'],
        'alternatives': classification.get('alternatives', []),
        'fields': fields,
        'cleaned_text': cleaned_text
    })

@app.route('/generate', methods=['POST'])
def generate():
    data = request.json
    format_type = data.get('format', 'letter')
    raw_text = data.get('raw_text', '')
    fields = data.get('fields', {})
    user_details = data.get('user_details', {})
    category = fields.get('category', 'Other')
    confidence = data.get('confidence', 0.0)
    
    formal_data = formalize_complaint(fields, raw_text)
    generated_docs = generate_document(format_type, formal_data, user_details)
    
    # Generate Reference Number
    ref_num = f"MH-{datetime.datetime.now().strftime('%Y%m%d')}-{os.urandom(2).hex().upper()}"
    
    # Save to SQLite History
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute(
            'INSERT INTO history (reference_number, raw_text, category, confidence, format, generated_text) VALUES (?, ?, ?, ?, ?, ?)',
            (ref_num, raw_text, category, confidence, format_type, generated_docs['mr'])
        )
        conn.commit()
        conn.close()
    except Exception as e:
        print(f"Database error: {e}")
    
    return jsonify({
        'text': generated_docs['mr'],
        'text_en': generated_docs['en'],
        'reference_number': ref_num
    })

@app.route('/history', methods=['GET'])
def get_history():
    """Returns the user's past generated complaints."""
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM history ORDER BY created_at DESC LIMIT 10')
        rows = cursor.fetchall()
        conn.close()
        return jsonify([dict(row) for row in rows])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/translate', methods=['POST'])
def translate():
    data = request.json
    translated = translate_text(data.get('text', ''), data.get('target_lang', 'en'))
    return jsonify({'translated_text': translated})

@app.route('/download/<filetype>', methods=['POST'])
def download(filetype):
    data = request.json
    text = data.get('text', '')
    
    if filetype not in ['pdf', 'docx']:
        return jsonify({'error': 'Invalid format'}), 400
        
    filename = f"Complaint_{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}.{filetype}"
    filepath = os.path.join(app.config['GENERATED_FOLDER'], filename)
    
    try:
        if filetype == 'pdf':
            create_pdf(text, filepath)
        else:
            create_docx(text, filepath)
        return send_file(filepath, as_attachment=True)
    except Exception as e:
        print(e)
        return jsonify({'error': 'Failed to generate file.'}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)
