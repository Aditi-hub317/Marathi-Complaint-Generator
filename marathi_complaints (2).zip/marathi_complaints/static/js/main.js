document.addEventListener('DOMContentLoaded', () => {
    // State management to hold extracted fields across screens
    let currentFields = {};
    let currentRawText = "";
    let currentGlobalLang = 'mr';

    const i18n = {
        'en': {
            appTitle: "Marathi Complaint Generator",
            appSubtitle: "AI-Powered Professional Grievance Drafting",
            enterComplaint: "Log Your Complaint",
            inputSubtitle: "Enter your complaint in informal Marathi, Roman Marathi, or mixed text. The AI will formalize it.",
            placeholderText: "e.g. My college hostel has no water for 3 days...",
            btnClear: "Clear",
            btnAnalyze: "Analyze & Formalize ➔",
            quickTry: "Quick Try:",
            recentHistory: "Recent History",
            verifyDetails: "Verify Details",
            formatRequired: "Format Required",
            formalLetter: "Formal Letter",
            application: "Application",
            email: "Email",
            shortGrievance: "Short Grievance",
            yourName: "Your Name",
            namePlaceholder: "e.g. Rahul Deshmukh",
            mobile: "Mobile",
            address: "Address/Dept",
            addressPlaceholder: "e.g. Room 12, Boys Hostel",
            authority: "Addressed To (Authority)",
            authorityPlaceholder: "e.g. The Principal, Govt College",
            btnBack: "← Back",
            btnGenerate: "Generate Document ➔",
            aiInsights: "AI Extraction Insights",
            viewRawJson: "View Raw JSON",
            docReady: "Your official document is ready",
            startOver: "Start Over",
            btnRegenerate: "⟳ Regenerate",
            btnDocx: "📄 DOCX",
            btnPdf: "📥 Download PDF"
        },
        'mr': {
            appTitle: "मराठी तक्रार निवारण",
            appSubtitle: "AI-Powered Professional Grievance Drafting",
            enterComplaint: "तुमची तक्रार नोंदवा",
            inputSubtitle: "Enter your complaint in informal Marathi, Roman Marathi, or mixed text. The AI will formalize it.",
            placeholderText: "उदा. माझ्या कॉलेजमध्ये गेल्या 3 दिवसांपासून पाणी नाहीये. वॉर्डनला सांगूनही काही झाले नाही...",
            btnClear: "पुसून टाका (Clear)",
            btnAnalyze: "विश्लेषण करा (Analyze)",
            quickTry: "Quick Try:",
            recentHistory: "Previous Complaints",
            verifyDetails: "तपशील तपासा (Verify Details)",
            formatRequired: "Format Required",
            formalLetter: "Formal Letter",
            application: "Application",
            email: "Email",
            shortGrievance: "Short Grievance",
            yourName: "तुमचे नाव (Your Name)",
            namePlaceholder: "उदा. राहुल देशमुख",
            mobile: "मोबाइल क्रमांक (Mobile)",
            address: "पत्ता / विभाग (Address/Dept)",
            addressPlaceholder: "उदा. खोली क्र. 12, बॉईज हॉस्टेल",
            authority: "प्राधिकरणाचे नाव (Authority / Addressed To)",
            authorityPlaceholder: "उदा. मा. प्राचार्य, शासकीय अभियांत्रिकी महाविद्यालय",
            btnBack: "← Back",
            btnGenerate: "Generate Document ➔",
            aiInsights: "AI Extraction Insights",
            viewRawJson: "View Raw JSON",
            docReady: "तुमचा अधिकृत अर्ज तयार आहे",
            startOver: "Start Over",
            btnRegenerate: "⟳ Regenerate",
            btnDocx: "📄 DOCX",
            btnPdf: "📥 Download PDF"
        }
    };

    document.getElementById('lang-toggle-btn').addEventListener('click', (e) => {
        currentGlobalLang = currentGlobalLang === 'mr' ? 'en' : 'mr';
        e.target.innerText = currentGlobalLang === 'mr' ? '🌐 English' : '🌐 मराठी';
        
        document.querySelectorAll('[data-i18n]').forEach(el => {
            const key = el.getAttribute('data-i18n');
            if(i18n[currentGlobalLang][key]) {
                el.innerText = i18n[currentGlobalLang][key];
            }
        });

        document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
            const key = el.getAttribute('data-i18n-placeholder');
            if(i18n[currentGlobalLang][key]) {
                el.placeholder = i18n[currentGlobalLang][key];
            }
        });
    });

    const showScreen = (id) => {
        document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
        document.getElementById(id).classList.add('active');
    };

    const loadHistory = async () => {
        try {
            const res = await fetch('/history');
            const data = await res.json();
            const timeline = document.getElementById('history-timeline');
            timeline.innerHTML = '';
            
            data.forEach(item => {
                const div = document.createElement('div');
                div.className = 'history-item';
                div.innerHTML = `
                    <div class="ref">${item.reference_number}</div>
                    <div class="cat">${item.category} (Format: ${item.format})</div>
                    <div style="font-size: 0.9rem; margin-top: 4px;">${item.created_at}</div>
                `;
                div.addEventListener('click', () => {
                    document.getElementById('generated-content').innerText = item.generated_text;
                    showScreen('result-screen');
                });
                timeline.appendChild(div);
            });
        } catch (e) {
            console.error('Failed to load history', e);
        }
    };
    
    loadHistory();

    // Input Screen
    const rawInput = document.getElementById('raw-complaint');
    
    document.querySelectorAll('.chip').forEach(chip => {
        chip.addEventListener('click', () => {
            rawInput.value = chip.innerText;
        });
    });

    document.getElementById('btn-clear').addEventListener('click', () => {
        rawInput.value = '';
    });

    const setBtnLoading = (btn, isLoading, originalText) => {
        if (isLoading) {
            btn.dataset.originalText = originalText || btn.innerText;
            btn.innerText = "Processing...";
            btn.disabled = true;
            btn.style.opacity = '0.7';
        } else {
            btn.innerText = btn.dataset.originalText;
            btn.disabled = false;
            btn.style.opacity = '1';
        }
    };

    // Toast Notification System
    const showToast = (message, type = 'error') => {
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.innerText = message;
        document.body.appendChild(toast);
        
        // Trigger animation
        setTimeout(() => toast.classList.add('show'), 10);
        
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    };

    document.getElementById('btn-analyze').addEventListener('click', async (e) => {
        const btn = e.target;
        const text = rawInput.value.trim();
        if (!text) {
            showToast('कृपया तुमची तक्रार लिहा. (Please enter a complaint)', 'error');
            return;
        }

        currentRawText = text; // Save for generation
        setBtnLoading(btn, true, btn.innerText);

        try {
            const response = await fetch('/analyze', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({text: text})
            });

            const data = await response.json();
            if(data.error) {
                showToast(data.error);
                setBtnLoading(btn, false);
                return;
            }

            // Save fields for generation
            currentFields = data.fields;
            currentFields.category = data.category; // Ensure category is included

            // Populate Analysis UI
            const resultsGrid = document.getElementById('analysis-results');
            resultsGrid.innerHTML = `
                <div class="result-card"><div class="result-label">Category</div><div class="result-value">${data.category} (${data.confidence}%)</div></div>
            `;
            
            for (const [key, value] of Object.entries(data.fields)) {
                if(value) {
                    resultsGrid.innerHTML += `<div class="result-card"><div class="result-label">${key.replace('_', ' ').toUpperCase()}</div><div class="result-value">${value}</div></div>`;
                }
            }

            document.getElementById('nlp-debug-info').innerText = JSON.stringify(data, null, 2);
            
            showScreen('analysis-screen');
        } catch (err) {
            console.error(err);
            showToast("Error connecting to server. Please try again.");
        } finally {
            setBtnLoading(btn, false);
        }
    });

    // Format Generation
    let generatedMr = "";
    let generatedEn = "";

    document.getElementById('btn-generate').addEventListener('click', async (e) => {
        const btn = e.target;
        const format = document.querySelector('input[name="format"]:checked').value;
        
        const userDetails = {
            name: document.getElementById('user-name').value.trim(),
            address: document.getElementById('user-address').value.trim(),
            mobile: document.getElementById('user-mobile').value.trim(),
            authority: document.getElementById('user-authority').value.trim(),
            date: new Date().toLocaleDateString('mr-IN')
        };
        
        setBtnLoading(btn, true, btn.innerText);

        try {
            const response = await fetch('/generate', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({
                    format: format,
                    raw_text: currentRawText,
                    fields: currentFields,
                    user_details: userDetails
                })
            });

            const data = await response.json();
            
            // Store locally for instant toggling
            generatedMr = data.text;
            generatedEn = data.text_en;
            
            // Default to Marathi
            document.getElementById('generated-content').innerText = generatedMr;
            document.getElementById('btn-lang-mr').classList.add('active');
            document.getElementById('btn-lang-en').classList.remove('active');
            
            showScreen('result-screen');
        } catch (err) {
            console.error(err);
            showToast("Error generating document.");
        } finally {
            setBtnLoading(btn, false);
        }
    });

    // Translation toggle (Now Instant & Native)
    document.getElementById('btn-lang-en').addEventListener('click', (e) => {
        if(generatedEn) {
            document.getElementById('generated-content').innerText = generatedEn;
            document.getElementById('btn-lang-mr').classList.remove('active');
            document.getElementById('btn-lang-en').classList.add('active');
        }
    });

    document.getElementById('btn-lang-mr').addEventListener('click', () => {
        if(generatedMr) {
            document.getElementById('generated-content').innerText = generatedMr;
            document.getElementById('btn-lang-en').classList.remove('active');
            document.getElementById('btn-lang-mr').classList.add('active');
        }
    });

    document.getElementById('btn-restart').addEventListener('click', () => {
        rawInput.value = '';
        showScreen('input-screen');
    });

    document.getElementById('btn-restart-1')?.addEventListener('click', () => {
        showScreen('input-screen');
    });

    document.getElementById('btn-regenerate').addEventListener('click', () => {
        document.getElementById('btn-generate').click();
    });

    // Speech API Setup
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition) {
        const recognition = new SpeechRecognition();
        recognition.lang = 'mr-IN';
        
        document.getElementById('btn-voice').addEventListener('click', () => {
            recognition.start();
            document.getElementById('raw-complaint').placeholder = "Listening... Speak in Marathi";
        });
        
        recognition.onresult = (event) => {
            rawInput.value += event.results[0][0].transcript;
        };
        
        recognition.onend = () => {
             document.getElementById('raw-complaint').placeholder = "उदा. माझ्या कॉलेजमध्ये गेल्या 3 दिवसांपासून पाणी नाहीये...";
        }
    } else {
        document.getElementById('btn-voice').style.display = 'none';
    }

    // Download Handlers
    const downloadDocument = async (format) => {
        const text = document.getElementById('generated-content').innerText;
        
        try {
            const response = await fetch(`/download/${format}`, {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({text: text})
            });
            
            if (response.ok) {
                const blob = await response.blob();
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `Complaint.${format}`;
                document.body.appendChild(a);
                a.click();
                window.URL.revokeObjectURL(url);
                a.remove();
            } else {
                showToast(`Failed to download ${format.toUpperCase()}`);
            }
        } catch (e) {
            console.error(e);
            showToast("Error downloading file.");
        }
    };

    document.getElementById('btn-pdf').addEventListener('click', () => downloadDocument('pdf'));
    document.getElementById('btn-docx').addEventListener('click', () => downloadDocument('docx'));
});
