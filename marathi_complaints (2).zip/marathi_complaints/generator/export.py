import os
import sqlite3
import datetime
import urllib.request
from docx import Document
from docx.shared import Pt
from docx.oxml.ns import qn
from fpdf import FPDF

FONT_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'static', 'fonts')
FONT_PATH = os.path.join(FONT_DIR, 'NotoSansDevanagari-Regular.ttf')
FALLBACK_FONT_PATH = os.path.join(FONT_DIR, 'NotoSans-Regular.ttf')

def ensure_font_exists():
    """Downloads required fonts if they don't exist."""
    os.makedirs(FONT_DIR, exist_ok=True)
    if not os.path.exists(FONT_PATH):
        print("Downloading Noto Sans Devanagari font...")
        url = "https://github.com/googlefonts/noto-fonts/raw/main/hinted/ttf/NotoSansDevanagari/NotoSansDevanagari-Regular.ttf"
        try:
            urllib.request.urlretrieve(url, FONT_PATH)
        except Exception as e:
            print(f"Failed to download Devanagari font: {e}")
            
    if not os.path.exists(FALLBACK_FONT_PATH):
        print("Downloading Noto Sans (Latin fallback) font...")
        url2 = "https://github.com/googlefonts/noto-fonts/raw/main/hinted/ttf/NotoSans/NotoSans-Regular.ttf"
        try:
            urllib.request.urlretrieve(url2, FALLBACK_FONT_PATH)
        except Exception as e:
            print(f"Failed to download Latin font: {e}")

def create_docx(text, filepath):
    """Generates a DOCX file with proper Complex Script (Devanagari) metadata."""
    doc = Document()
    
    # Configure the document to support Complex Script (Marathi) rendering
    style = doc.styles['Normal']
    font = style.font
    font.name = 'Mangal'  # Default Devanagari font on Windows
    font.size = Pt(12)
    # This XML tag explicitly tells MS Word to apply proper text shaping for Devanagari
    font._element.rPr.rFonts.set(qn('w:cs'), 'Mangal')
    
    for line in text.split('\n'):
        doc.add_paragraph(line)
        
    doc.save(filepath)
    return filepath

def create_pdf(text, filepath):
    """Generates a PDF file with complete HarfBuzz text shaping for Devanagari."""
    ensure_font_exists()
    
    # Initialize fpdf2 with text shaping enabled to perfectly combine Marathi matras and conjuncts
    pdf = FPDF()
    pdf.set_text_shaping(True)
    pdf.add_page()
    
    try:
        # Register the Devanagari font and Latin fallback
        pdf.add_font("Devanagari", "", FONT_PATH)
        if os.path.exists(FALLBACK_FONT_PATH):
            pdf.add_font("Latin", "", FALLBACK_FONT_PATH)
            pdf.set_fallback_fonts(["Latin"])
        
        pdf.set_font("Devanagari", size=12)
    except Exception as e:
        print(f"Font registration failed, using fallback: {e}")
        pdf.set_font("Helvetica", size=12)

    # multi_cell automatically handles text wrapping for A4 size
    pdf.multi_cell(0, 7, text)
    
    pdf.output(filepath)
    return filepath
