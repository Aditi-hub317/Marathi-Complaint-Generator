def generate_letter(formal_data, user_details, lang='mr'):
    """Generates an Ultra-Formal Complaint Letter (Government Level)."""
    if lang == 'en':
        authority = user_details.get('authority') or "[Authority Name & Designation]"
        subject = formal_data['subject_en']
        body = formal_data['body_en']
        name = user_details.get('name') or "[Complainant's Name]"
        date = user_details.get('date') or "[Date]"
        address = user_details.get('address') or "[Full Address]"
        return f"""To,
{authority}

Subject: {subject}
Reference: Ongoing grievances and inconvenience caused to the public/students.

Respected Sir/Madam,

{body}

Thank you.

Yours sincerely,

(Signature)
--------------------
{name}
{address}
Date: {date}
"""
    else:
        authority = user_details.get('authority') or "[प्राधिकरणाचे/अधिकाऱ्याचे पद व नाव]"
        subject = formal_data['subject']
        body = formal_data['body']
        name = user_details.get('name') or "[तक्रारदाराचे नाव]"
        date = user_details.get('date') or "[दिनांक]"
        address = user_details.get('address') or "[संपूर्ण पत्ता]"
        
        return f"""प्रति,
{authority}

विषय: {subject}
संदर्भ: चालू परिस्थिती व नागरिकांची/विद्यार्थ्यांची गैरसोय.

महोदय/महोदया,

{body}

धन्यवाद.

आपला/आपली नम्र,

(स्वाक्षरी)
--------------------
{name}
{address}
दिनांक: {date}
"""

def generate_application(formal_data, user_details, lang='mr'):
    """Generates a structured Institutional Application format."""
    if lang == 'en':
        authority = user_details.get('authority') or "[Principal/HOD]"
        subject = formal_data['subject_en']
        body = formal_data['body_en']
        name = user_details.get('name') or "[Applicant's Name]"
        date = user_details.get('date') or "[Date]"
        return f"""FORMAL APPLICATION
        
To,
{authority}

Subject: {subject}

Respected Sir/Madam,

{body}

Yours obediently,
{name}
Date: {date}
"""
    else:
        authority = user_details.get('authority') or "[प्राचार्य/विभागप्रमुख]"
        subject = formal_data['subject']
        body = formal_data['body']
        name = user_details.get('name') or "[अर्जदाराचे नाव]"
        date = user_details.get('date') or "[दिनांक]"
        
        return f"""अधिकृत अर्ज
        
प्रति,
{authority}

विषय: {subject}

महोदय/महोदया,

{body}

आपला/आपली आज्ञाधारक,
{name}
दिनांक: {date}
"""

def generate_email(formal_data, user_details, lang='mr'):
    """Generates a highly professional Corporate/Institutional Email."""
    if lang == 'en':
        subject = formal_data['subject_en']
        body = formal_data['body_en']
        name = user_details.get('name') or "[Your Name]"
        mobile = user_details.get('mobile') or "[Your Mobile Number]"
        return f"""To: [Official Email Address]
Subject: URGENT: {subject}

Respected Sir/Madam,

{body}

Regards,
{name}
Contact: {mobile}
"""
    else:
        subject = formal_data['subject']
        body = formal_data['body']
        name = user_details.get('name') or "[तुमचे नाव]"
        mobile = user_details.get('mobile') or "[तुमचा मोबाइल क्रमांक]"
        
        return f"""To: [संबंधित विभागाचा अधिकृत ई-मेल]
Subject: अत्यंत महत्त्वाचे: {subject}

महोदय/महोदया,

{body}

Regards,
{name}
Contact: {mobile}
"""

def generate_short_complaint(formal_data, user_details, lang='mr'):
    """Generates a concise grievance for Web Portals/CM Helpline."""
    if lang == 'en':
        subject = formal_data['subject_en']
        body = formal_data['body_en']
        clean_body = body.replace("Respected Sir/Madam,\n\nI am writing to formally bring to your attention some serious ongoing issues and inconveniences.\n\n", "")
        clean_body = clean_body.replace("\n\n", " ")
        return f"""Grievance Subject: {subject}
Details: {clean_body}"""
    else:
        subject = formal_data['subject']
        body = formal_data['body']
        clean_body = body.replace("सविनय सप्रेम नमस्कार,\n\nमी या पत्राद्वारे आपल्या निदर्शनास आणून देऊ इच्छितो की, येथील कामकाजात व सुविधांमध्ये काही गंभीर अडचणी निर्माण झाल्या आहेत.\n\n", "")
        clean_body = clean_body.replace("\n\n", " ")
        return f"""तक्रार विषय: {subject}
तपशील: {clean_body}"""

def generate_document(format_type, formal_data, user_details):
    """Routing function for generating BOTH specific formats simultaneously."""
    if format_type == 'application':
        return {
            'mr': generate_application(formal_data, user_details, 'mr'),
            'en': generate_application(formal_data, user_details, 'en')
        }
    elif format_type == 'email':
        return {
            'mr': generate_email(formal_data, user_details, 'mr'),
            'en': generate_email(formal_data, user_details, 'en')
        }
    elif format_type == 'short':
        return {
            'mr': generate_short_complaint(formal_data, user_details, 'mr'),
            'en': generate_short_complaint(formal_data, user_details, 'en')
        }
    else:
        return {
            'mr': generate_letter(formal_data, user_details, 'mr'),
            'en': generate_letter(formal_data, user_details, 'en')
        }
