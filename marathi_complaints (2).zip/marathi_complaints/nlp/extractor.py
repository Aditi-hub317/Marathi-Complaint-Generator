import re

def extract_information(text, category):
    """
    Extract structured fields using heuristics.
    Never invents information. If a field is not found, returns None.
    """
    text_lower = text.lower()
    
    fields = {
        "issue": None,
        "location": None,
        "duration": None,
        "date": None,
        "authority": None,
        "previous_action": None,
        "status": "Unresolved", # If they are complaining, it's unresolved
        "impact": None,
        "requested_action": None,
        "urgency": "Medium"
    }

    # Extract Duration (e.g. 3 divas, don mahine, 1 week, गेल्या 3 दिवसांपासून)
    duration_match = re.search(r'(\d+|ek|don|tin|char|pach|saha|saat|aath|nau|daha|एक|दोन|तीन|चार|पाच|सहा|सात|आठ|नऊ|दहा)\s*(divas|mahina|mahine|week|varsh|तास|दिवस|महिने|आठवडे|वर्षे?)', text_lower)
    if duration_match:
        fields["duration"] = duration_match.group(0).strip()
    
    # Extract Authority
    authorities = {
        'warden': 'वॉर्डन', 'वॉर्डन': 'वॉर्डन', 
        'principal': 'प्राचार्य', 'प्राचार्य': 'प्राचार्य', 
        'sir': 'महोदय', 'madam': 'महोदया', 'महोदय': 'महोदय', 
        'manager': 'व्यवस्थापक', 'व्यवस्थापक': 'व्यवस्थापक', 
        'sarpanch': 'सरपंच', 'सरपंच': 'सरपंच', 
        'police': 'पोलीस', 'पोलीस': 'पोलीस'
    }
    for auth, mr_auth in authorities.items():
        if auth in text_lower:
            fields["authority"] = mr_auth
            break
            
    # Extract Location
    locations = {
        'hostel': 'वसतिगृह', 'वसतिगृह': 'वसतिगृह', 
        'college': 'महाविद्यालय', 'महाविद्यालय': 'महाविद्यालय', 
        'campus': 'कॅम्पस', 'कॅम्पस': 'कॅम्पस', 
        'library': 'ग्रंथालय', 'ग्रंथालय': 'ग्रंथालय', 
        'mess': 'मेस', 'मेस': 'मेस', 
        'canteen': 'कॅन्टीन', 'कॅन्टीन': 'कॅन्टीन', 
        'hospital': 'रुग्णालय', 'दवाखाना': 'दवाखाना', 
        'office': 'कार्यालय', 'कार्यालय': 'कार्यालय', 
        'bank': 'बँक', 'बँक': 'बँक',
        'area': 'परिसर', 'परिसर': 'परिसर'
    }
    for loc, mr_loc in locations.items():
        if loc in text_lower:
            fields["location"] = mr_loc
            break
            
    # Previous Action
    prev_actions = ['sangun pan', 'सांगूनही', 'complaint karun', 'तक्रार करून', 'form submit karun', 'अर्ज देऊनही']
    for action in prev_actions:
        if action in text_lower:
            fields["previous_action"] = "Previous complaint/request was made but no action taken"
            break
            
    # Urgency Heuristics
    high_urgency_words = ['emergency', 'urgent', 'lakshya dya', 'kahi tari kara', 'londha', 'rashtriya', 'tadbhadak', 'atishay', 'emergency', 'ताबडतोब', 'लवकर']
    if any(word in text_lower for word in high_urgency_words):
        fields["urgency"] = "High"

    # Issue extraction (fallback to raw text if no specific noun phrase is identified)
    # To prevent hallucination, the issue is safely assumed to be the core text.
    # In a full academic NLP project, POS tagging/dependency parsing would be used.
    # For now, we take the raw text and trim it.
    
    issue_text = text
    # Clean up some starting/ending noise for the issue
    issue_text = re.sub(r'^(sir|madam|please|hello|hi|महोदय|महोदया|कृपया)\s*', '', issue_text, flags=re.IGNORECASE)
    fields["issue"] = issue_text.strip()
    
    # Clean up empty strings
    for k, v in fields.items():
        if v == "":
            fields[k] = None

    return fields
