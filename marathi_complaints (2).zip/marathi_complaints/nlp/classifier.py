import os
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
import joblib

MODEL_PATH = os.path.join(os.path.dirname(__file__), '../models/complaint_model.pkl')
DATASET_PATH = os.path.join(os.path.dirname(__file__), '../dataset/marathi_complaints.csv')

def train_model():
    """Trains the TF-IDF + Logistic Regression classifier on the dataset."""
    if not os.path.exists(DATASET_PATH):
        raise FileNotFoundError(f"Dataset not found at {DATASET_PATH}")
        
    df = pd.read_csv(DATASET_PATH)
    
    # Pipeline: TF-IDF with character n-grams (2-4) to handle mixed scripts
    # Logistic Regression with balanced class weights
    pipeline = Pipeline([
        ('tfidf', TfidfVectorizer(analyzer='char_wb', ngram_range=(2, 4))),
        ('clf', LogisticRegression(class_weight='balanced', C=1.0, max_iter=1000))
    ])
    
    pipeline.fit(df['text'], df['category'])
    
    # Save the model
    os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)
    joblib.dump(pipeline, MODEL_PATH)
    return pipeline

_MODEL_CACHE = None

def get_model():
    """Loads the model into memory once and caches it."""
    global _MODEL_CACHE
    if _MODEL_CACHE is not None:
        return _MODEL_CACHE
        
    if os.path.exists(MODEL_PATH):
        _MODEL_CACHE = joblib.load(MODEL_PATH)
        return _MODEL_CACHE
    
    _MODEL_CACHE = train_model()
    return _MODEL_CACHE

def classify_complaint(text):
    """
    Classifies the text and returns the category, confidence, and alternatives if low confidence.
    """
    model = get_model()
    
    # Predict probabilities
    probs = model.predict_proba([text])[0]
    classes = model.classes_
    
    # Sort by probability
    top_indices = probs.argsort()[::-1]
    
    top_category = classes[top_indices[0]]
    top_confidence = round(probs[top_indices[0]] * 100, 2)
    
    # If confidence is low (< 30%), fallback to Other and provide alternatives
    alternatives = []
    if top_confidence < 30.0 and top_category != "Other":
        alternatives = [classes[i] for i in top_indices[:3] if classes[i] != "Other"]
        top_category = "Other"
        
    return {
        "category": top_category,
        "confidence": top_confidence,
        "alternatives": alternatives
    }

if __name__ == "__main__":
    # Test training
    train_model()
    print("Model trained successfully.")
