
from nlp.translator import translate_text

def generate_subject(category, issue, location):
    """
    Generates a highly formal, natural Marathi and English subject without inventing facts.
    """
    subject_map_mr = {
        "Hostel": "वसतिगृहातील", "Education": "महाविद्यालयातील", "Transport": "वाहतूक सेवेतील",
        "Water Supply": "पाणीपुरवठा", "Electricity": "विद्युत पुरवठ्यातील", "Internet/WiFi": "इंटरनेट सेवेतील",
        "Healthcare": "वैद्यकीय सुविधेतील", "Government Services": "शासकीय कामकाजातील",
        "Workplace": "कार्यालयीन", "Municipal Services": "नागरी", "Banking": "बँकिंग सेवेतील", "Other": "सार्वजनिक"
    }
    
    subject_map_en = {
        "Hostel": "Hostel", "Education": "Educational", "Transport": "Transport",
        "Water Supply": "Water Supply", "Electricity": "Electricity", "Internet/WiFi": "Internet/WiFi",
        "Healthcare": "Healthcare", "Government Services": "Government Services",
        "Workplace": "Workplace", "Municipal Services": "Municipal", "Banking": "Banking", "Other": "Public"
    }

    prefix_mr = subject_map_mr.get(category, "सार्वजनिक")
    prefix_en = subject_map_en.get(category, "Public")
    
    if location:
        subj_mr = f"{location} येथील {prefix_mr} समस्येबाबत."
        subj_en = f"Regarding the {prefix_en} issue at {location}."
    else:
        subj_mr = f"{prefix_mr} समस्येबाबत व तातडीने उपाययोजना करण्याविषयी."
        subj_en = f"Regarding the {prefix_en} issue and request for immediate action."
        
    return {"mr": subj_mr, "en": subj_en}

def get_natural_issue_description(category, raw_text):
    """
    Provides a naturally flowing, highly professional Devanagari description of the problem
    WITHOUT hallucinating or replacing facts with generic templates.
    """
    is_devanagari = any('\u0900' <= char <= '\u097F' for char in raw_text)
    
    if is_devanagari:
        clean_text = raw_text.strip()
        en_clean = translate_text(raw_text, target_lang='en')
        if "[Translation" in en_clean or en_clean == raw_text:
            en_clean = raw_text.strip()
    else:
        en_text = translate_text(raw_text, target_lang='en')
        en_clean = en_text if "[Translation" not in en_text else raw_text.strip()
        
        clean_text = translate_text(en_clean, target_lang='mr')
        if "[Translation" in clean_text or clean_text == en_clean:
            clean_text = raw_text.strip()
            
    return {
        "mr": f"माझी प्रमुख तक्रार अशी आहे की: {clean_text}",
        "en": f"My primary grievance is as follows: {en_clean}"
    }

def formalize_complaint(extracted_fields, raw_text):
    """
    Transforms extracted fields into a naturally flowing, highly empathetic, and professional Marathi and English letter.
    """
    body_mr = []
    body_en = []
    
    # 1. Natural Opening
    location = extracted_fields.get('location', '')
    location_text = f" {location} येथील" if location else " येथील"
    location_en = f" at {location}" if location else ""
    
    body_mr.append(f"सविनय सप्रेम नमस्कार,\n\nमी या पत्राद्वारे आपल्या निदर्शनास आणून देऊ इच्छितो की,{location_text} कामकाजात व सुविधांमध्ये काही गंभीर अडचणी निर्माण झाल्या आहेत.")
    body_en.append(f"Respected Sir/Madam,\n\nI am writing to formally bring to your attention some serious ongoing issues and inconveniences{location_en}.")
    
    # 2. Seamlessly integrated issue statement
    issue_desc = get_natural_issue_description(extracted_fields.get('category', 'Other'), raw_text)
    
    duration = extracted_fields.get('duration', '')
    duration_mr = f" अत्यंत खेदाची बाब म्हणजे, ही परिस्थिती गेल्या {duration} पासून सातत्याने कायम आहे." if duration else ""
    duration_en = f" It is highly regrettable to state that this situation has been persisting for the past {duration}." if duration else ""
    
    body_mr.append(f"{issue_desc['mr']}{duration_mr}")
    body_en.append(f"{issue_desc['en']}{duration_en}")
    
    # 3. Previous Escalation (Flows naturally)
    prev_action = extracted_fields.get('previous_action', False)
    if prev_action:
        auth_name = extracted_fields.get('authority', "संबंधित प्रशासनाला") or "संबंधित प्रशासनाला"
        auth_name_en = extracted_fields.get('authority', "the relevant administration") or "the relevant administration"
        
        body_mr.append(f"या संदर्भात आम्ही यापूर्वीच {auth_name} तोंडी व लेखी स्वरूपात पूर्वकल्पना दिली होती. परंतु, दुर्दैवाने अद्यापपर्यंत यावर कोणताही ठोस तोडगा काढण्यात आलेला नाही.")
        body_en.append(f"We had previously escalated this matter to {auth_name_en} verbally and in writing. Unfortunately, no concrete resolution has been provided thus far.")
        
    # 4. Closing Request (Respectful and firm)
    urgency = extracted_fields.get('urgency', 'Low')
    urgency_mr = "तातडीने" if urgency == "High" else "लवकरात लवकर"
    urgency_en = "immediately" if urgency == "High" else "at the earliest"
    
    body_mr.append(f"या समस्येमुळे आमचे मोठ्या प्रमाणावर नुकसान व गैरसोय होत आहे. तरी माझी आपणास नम्र विनंती आहे की, आपण स्वतः या प्रकरणात लक्ष घालावे आणि संबंधितांना {urgency_mr} योग्य ती कार्यवाही करण्याचे आदेश द्यावेत.")
    body_mr.append("आपल्या सहकार्याची आणि त्वरित कारवाईची अपेक्षा आहे.")
    
    body_en.append(f"This issue is causing significant distress and inconvenience. I sincerely request you to personally look into this matter and direct the concerned personnel to take appropriate action {urgency_en}.")
    body_en.append("Anticipating your cooperation and prompt action.")
    
    formal_body_mr = "\n\n".join(body_mr)
    formal_body_en = "\n\n".join(body_en)
    
    subject = generate_subject(extracted_fields.get('category', 'Other'), extracted_fields.get('issue', ''), extracted_fields.get('location', ''))
    
    return {
        "subject": subject['mr'],
        "body": formal_body_mr,
        "subject_en": subject['en'],
        "body_en": formal_body_en
    }
