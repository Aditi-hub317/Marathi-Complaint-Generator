import re

def preprocess_text(text):
    """
    Preprocess Marathi, Roman Marathi, and mixed text.
    - Normalizes common Roman Marathi words to Devanagari.
    - Removes unnecessary punctuation while preserving dates and numbers.
    - Converts to lowercase for consistency (helps with Roman Marathi/English).
    """
    if not text:
        return ""

    text = text.lower().strip()
    
    # Simple dictionary for common Roman Marathi to Devanagari normalization
    # This helps the TF-IDF model generalize better.
    roman_to_devanagari = {
        r'\bnahi\b': 'नाही',
        r'\bnaahi\b': 'नाही',
        r'\bno\b': 'नाही',
        r'\bpani\b': 'पाणी',
        r'\bpaani\b': 'पाणी',
        r'\bwater\b': 'पाणी',
        r'\bcollege\b': 'महाविद्यालय',
        r'\bhostel\b': 'वसतिगृह',
        r'\bproblem\b': 'समस्या',
        r'\bissue\b': 'अडचण',
        r'\bdivas\b': 'दिवस',
        r'\bdays\b': 'दिवस',
        r'\bweek\b': 'आठवडा',
        r'\bmahina\b': 'महिना',
        r'\bmonth\b': 'महिना',
        r'\bkhup\b': 'खूप',
        r'\blavkar\b': 'लवकर',
        r'\bband\b': 'बंद',
        r'\bchalu\b': 'सुरू',
        r'\bstart\b': 'सुरू',
        r'\bstop\b': 'बंद',
        r'\bmadhe\b': 'मध्ये',
        r'\bplease\b': 'कृपया',
        r'\bsir\b': 'महोदय',
        r'\bmadam\b': 'महोदया',
        r'\btakrar\b': 'तक्रार',
        r'\bcomplaint\b': 'तक्रार',
        r'\blight\b': 'वीज',
        r'\belectricity\b': 'वीज',
        r'\bkachra\b': 'कचरा',
        r'\bgarbage\b': 'कचरा',
        r'\brasta\b': 'रस्ता',
        r'\broad\b': 'रस्ता',
        r'\bwarden\b': 'वॉर्डन',
        r'\bprincipal\b': 'प्राचार्य',
        r'\barea\b': 'परिसर',
        r'\bbhagat\b': 'भागात',
        r'\bgelya\b': 'गेल्या',
        r'\bmajhya\b': 'माझ्या',
        r'\bmazya\b': 'माझ्या'
    }

    # Apply substitutions
    for roman, devanagari in roman_to_devanagari.items():
        text = re.sub(roman, devanagari, text)

    # Remove extra spaces
    text = re.sub(r'\s+', ' ', text)
    
    # We DO NOT remove numbers or structural punctuation entirely, 
    # as the Extractor needs them for dates, duration, etc.
    return text.strip()
