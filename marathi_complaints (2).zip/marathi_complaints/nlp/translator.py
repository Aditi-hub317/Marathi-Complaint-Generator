from deep_translator import GoogleTranslator, MyMemoryTranslator

def translate_text(text, target_lang='en'):
    """
    Translates text paragraph by paragraph to avoid length limits (MyMemory has a 500 char limit).
    """
    paragraphs = text.split('\n')
    translated_paragraphs = []
    
    for p in paragraphs:
        if not p.strip():
            translated_paragraphs.append("")
            continue
            
        try:
            # Try Google first
            translated = GoogleTranslator(source='auto', target=target_lang).translate(p)
            translated_paragraphs.append(translated)
        except Exception as e:
            try:
                # Fallback to MyMemory if Google rate limits
                # MyMemory uses specific locale codes like mr-IN and en-GB
                source_mm = 'mr-IN' if target_lang == 'en' else 'en-GB'
                target_mm = 'en-GB' if target_lang == 'en' else 'mr-IN'
                
                # If paragraph is still > 490 chars, chunk it roughly
                if len(p) > 490:
                    chunks = [p[i:i+490] for i in range(0, len(p), 490)]
                    chunk_trans = []
                    for chunk in chunks:
                        chunk_trans.append(MyMemoryTranslator(source=source_mm, target=target_mm).translate(chunk))
                    translated_paragraphs.append(" ".join(chunk_trans))
                else:
                    translated = MyMemoryTranslator(source=source_mm, target=target_mm).translate(p)
                    translated_paragraphs.append(translated)
            except Exception as e2:
                # If both fail, keep the original paragraph so the layout doesn't break
                translated_paragraphs.append(p)

    return "\n".join(translated_paragraphs)
